
For standalone installation,

    - Login as root. (You must be root in order to apply the update.) 

    - Place the Smart Component (CPxxxxxx.zip) in a temporary directory 

    - From the same directory, unzip the Smart Component:
               unzip CPxxxxxx.zip

    - Ensure that the file CPxxxxxx.vmexe is executable.
      Execute the commmand:

	chmod +x CPxxxxxx.vmexe

    - To perform the standalone installation, execute the command: 

             ./CPxxxxxx.vmexe    ( for ESXi 6.*)  or
             ./CPxxxxxx.vmexe64  ( for ESXi 7.*)
        

    - Follow the directions given by the Smart Component 

    - If instructed, reboot your system for the firmware update to take effect 


NOTE: If the VMware ESXi operating system is installed on SD flash media or USB key, 
      copy the component to a directory that is not mapped  to the SD Flash or the USB key, 
      such as /tmp, to avoid delays during the execution of the component.

      If an error message is seen with the text "No space left on device", 
      please either remove all unnecessary files in the directory that is being used or 
      use a larger directory (usually /tmp has plenty of space ).  Then, try again.

